<?php
//Variables
$name = block_value('name');
?>
<div class="title-block-products-view">
    <h2 class="text"><?php echo $name ?></h2>
</div>