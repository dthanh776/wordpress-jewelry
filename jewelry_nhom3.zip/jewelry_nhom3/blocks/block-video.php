<div class="row-fluid  div-full-page-outer">
    <div class="span16 div-full-page">
        <div class="ty-wysiwyg-content">
            <div class="wrap-stores" style="text-align:center;"> <img style="filter: brightness(0.5);" src="<?php echo block_field('image') ?>"> <span><a href="/ho-tro-mua-hang/he-thong-cua-hang/"><?php echo block_field('title') ?></a></span></div>
        </div>
        <div class="ty-wysiwyg-content">
            <div class="wrap-archives">
                <div class="content-iframe"> <iframe src="<?php echo block_field('video') ?>" loading="lazy" frameborder="0"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" width="100%" height="100%"></iframe> </div>
            </div>
        </div>
    </div>
</div>