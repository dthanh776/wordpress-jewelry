<?php
//Variables
$phone = block_value('phone');
?>
    <div class="group-prom-online-store">
    <div class="ty-wysiwyg-content" style="width:100%!important"><div class="holine-store-outer"> 
    <h2> Gọi HOTLINE <span>(miễn phí)</span><br> <span>để kiểm tra cửa hàng còn hàng</span> </h2> 
    <p class="text"> <a href="tel:<?php echo $phone ?>"><?php echo $phone ?></a> </p> 
    <p class="btn-outer"> <a href="tel:<?php echo $phone ?>">Gọi ngay</a> </p> </div>
    </div>
</div>

