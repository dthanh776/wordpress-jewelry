<div class="tygh-content clearfix">
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span16">

      </div>
    </div>
    <div class="row-fluid">

        <div class="wysiwyg-content">
          <div class="post-detail-content">
            <div class="pages-pnj">
              <div
                class="myAccordion mp-outer-popup mp-product-description-general-v2 mp-gold mp-column-1 mpcolumn"
                id="mp-product-description-general-v2">
                <div class="item">
                  <div class="question">
                    <span class=""></span>
                    <h2><?php block_field('questions') ?></h2>
                  </div>
                  <div class="answer">
                    <div class="layout-content">
                      <div style="border-top:1px solid rgb(0, 51, 104, 0.4);" class="panel_sub">
                        <?php block_field('answers') ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Inline script moved to the bottom of the page -->
        </div>
      <div class="row-fluid">
        <div class="span16">
          <div class="ty-wysiwyg-content">
           
          </div>
          <div class="ty-wysiwyg-content">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
 <style>
              .general .wysiwyg-content .params-new.mp-detail-blog {
                display: none;
              }
#mp-product-description-general-v2 {
    margin: 0;
    padding:0;
}

              .general
                #mp-product-description-general-v2.myAccordion
                .question
                .icon {
                    
              }

              .general #mp-product-description-general-v2.myAccordion .answer {
                padding: 0 !important;
              }

              .general#blog .post-detail-content ul,
              .general#mp_video .post-detail-content ul {
                padding-left: 20px;
                box-sizing: border-box;
              }

              .general .pages-pnj {
                max-width: 800px;
                margin: auto;
              }

              .general#blog .post-detail-content ul li,
              .general#mp_video .post-detail-content ul li {
                list-style: disc;
              }

              .layout-content .note {
                font-style: italic;
              }

              .general#blog .post-detail-content .pages-pnj .text.giaidoan {
                text-align: center;
                color: #003368 !important;
                font-weight: 600;
              }

              .general#blog #mp-product-description-general-v2 p,
              .general#blog .post-detail-content .pages-pnj p.text-content,
              .general#blog .post-detail-content .pages-pnj p.text-content em,
              .general#mp_video #mp-product-description-general-v2 p {
                font-size: 15px;
              }

              .general#blog .post-detail-content .pages-pnj p.accordion_sub,
              .general#blog .post-detail-content .pages-pnj p.cauhoi {
                font-weight: 600 !important;
                cursor: pointer;
                transition: 0.4s;
                padding-left: 10px;
                padding-right: 10px;
              }

              .general#blog .post-detail-content .pages-pnj .panel_sub {
                padding: 0 10px;
                max-height: 0;
                overflow: hidden;
                transition: max-height 0.2s ease-out;
              }

              .general#blog.desktop
                .post-detail-content
                .pages-pnj
                p.image
                img {
                max-width: 500px;
              }

              #mp-product-description-general-v2 p {
                text-align: left;
              }

              #mp-product-description-general-v2 h3,
              #mp-product-description-general-v2 h4 {
                font-weight: 600;
                margin-bottom: 0;
              }

              .general#blog .post-detail-content .pages-pnj *,
              .general#mp_video .post-detail-content .pages-pnj * {
                line-height: 20px;
              }

              #mp-product-description-general-v2 a,
              .general#blog .pages-pnj p a,
              #mp-product-description-general-v2 p a {
                color: #337ab7 !important;
                font-weight: 400;
              }

              .general.desktop .wysiwyg-content .table {
                /*max-width:445px!important;*/
                overflow-x: auto;
                margin: auto;
              }

              .general#blog.desktop .post-title,
              .general#mp_video .post-title {
                font-size: 26px;
                text-align: center;
                font-weight: bold;
                color: #0f3564;
              }

              .general
                #mp-product-description-general-v2.myAccordion
                .question-child {
                cursor: pointer;
              }

              .general
                #mp-product-description-general-v2.myAccordion
                .answer
                .layout-content {
                max-width: none;
                padding: 10px;
              }

              .general .ty-tygh h4.title {
                font-weight: bold;
              }

              .general#blog.desktop
                #mp-product-description-general-v2
                .mp-images,
              #mp-product-description-general-v2 img {
                max-width: 70%;
              }

              .general
                #mp-product-description-general-v2.myAccordion
                .expanded.question-child:before {
                display: inline-block;
                content: "-";
                width: 15px;
              }

              .general
                #mp-product-description-general-v2.myAccordion
                .question-child:before {
                display: inline-block;
                content: "+";
                width: 15px;
              }

              .general#blog #mod-sp-customer #customerCont .left {
                max-width: none;
                float: none;
              }

              .general#blog .pages-pnj .question h2.special {
                filter: hue-rotate(190deg) contrast(152%);
                -webkit-filter: hue-rotate(190deg) contrast(152%);
                -moz-filter: hue-rotate(190deg) contrast(152%);
                
         
              }

              .general#blog .ty-mainbox-container h1.ty-mainbox-title {
                font-size: 30px;
                color: #0f3564;
                text-align: center;
                position: relative;
                text-transform: uppercase;
                border-bottom: none;
                font-weight: bold;
              }

              .general #mp-product-description-general-v2.myAccordion .item {
                border: 1px solid rgb(0, 51, 104, 0.4);
                border-radius: 10px;
              }

              .general
                #mp-product-description-general-v2.myAccordion
                .question {
                background: transparent;
                display: block;
                margin: 0 5px;
              }

             .post-detail-content .pages-pnj .question h2 {
                font-size: 16px;
                display: block;
                position: relative;
                text-transform: none;
                padding: 0 15px;
                text-align: left;
                position: relative;
                box-sizing: border-box;
                font-weight: bold;
                margin: 12px 0 12px;
                color: #4a4a4a !important;
                cursor: pointer;
              }

              .general#blog .post-detail-content .pages-pnj .question.expanded {
                border-bottom: 1px solid rgb(0, 51, 104, 0.4);
              }

              .general#blog.desktop
                .post-detail-content
                .pages-pnj
                .question
                h2 {
                padding-right: 46px;
              }

              .general #mod-sp-customer #customerCont .the-step ul {
                list-style: disc;
                padding-left: 25px;
              }

              .general #mod-sp-customer #customerCont .text-step ul li {
                font-weight: normal;
              }

              .general #mod-sp-customer #customerCont .the-step table td ul {
                text-align: left;
              }

              .general#blog
                #mp-product-description-general-v2.myAccordion
                .question
                .icon {
                display: inline-block;
                background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMC43MDciIGhlaWdodD0iMTAuNzA3IiB2aWV3Qm94PSIwIDAgMjAuNzA3IDEwLjcwNyI+CiAgPGcgaWQ9Ikdyb3VwXzEyMyIgZGF0YS1uYW1lPSJHcm91cCAxMjMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUuMzU0IDAuMzU0KSI+CiAgICA8bGluZSBpZD0iTGluZV8zNyIgZGF0YS1uYW1lPSJMaW5lIDM3IiB4Mj0iMTAiIHkyPSIxMCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTUpIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDM0NjgiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIwLjUiLz4KICAgIDxsaW5lIGlkPSJMaW5lXzM4IiBkYXRhLW5hbWU9IkxpbmUgMzgiIHkxPSIxMCIgeDI9IjEwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAzNDY4IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS13aWR0aD0iMC41Ii8+CiAgPC9nPgo8L3N2Zz4K) !important;
                background-repeat: no-repeat;
                background-position: 0px 0px;
                width: 21px;
                height: 12px;
                margin-left: 20px;
                margin-left: 0;
                position: absolute;
                top: 60%;
                right: 0;
              }

              .general#blog
                #mp-product-description-general-v2.myAccordion
                .question.expanded
                .icon {
                background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMC43MDciIGhlaWdodD0iMTAuNzA3IiB2aWV3Qm94PSIwIDAgMTAuNzA3IDEwLjcwNyI+CiAgPGcgaWQ9Ikdyb3VwXzEzMSIgZGF0YS1uYW1lPSJHcm91cCAxMzEiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00LjE0NiAtMjg3LjE0NikiPgogICAgPGxpbmUgaWQ9IkxpbmVfMzciIGRhdGEtbmFtZT0iTGluZSAzNyIgeDI9IjEwIiB5Mj0iMTAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDQuNSAyODcuNSkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMzQ2OCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjAuNSIvPgogICAgPGxpbmUgaWQ9IkxpbmVfMzgiIGRhdGEtbmFtZT0iTGluZSAzOCIgeTE9IjEwIiB4Mj0iMTAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDQuNSAyODcuNSkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMzQ2OCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjAuNSIvPgogIDwvZz4KPC9zdmc+Cg==) !important;
                background-position: center center;
              }

              .general#blog .author,
              .general#mp_video .author {
                margin: 20px auto !important;
                max-width: 800px;
                display: block;
              }

              .general#blog .mp-param-cover,
              .general#mp_video .mp-param-cover {
                max-width: 800px;
                display: block;
                margin-left: auto;
                margin-right: auto;
              }
            </style>