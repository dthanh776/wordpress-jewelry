<?php
get_header();
?>
        <!-- Breadcrumbs & Page Title Start -->
        <div class="breadcrumbs-title bg-img-4 parallax overlay dark-5 blank-space">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="breadcrumbs-menu ptb-150">
                            <h1 class="l-height"><?php _e('Search results','glw'); ?></h1>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- Breadcrumbs & Page Title End -->
        <!-- Blog Section Start -->
        <section class="blog-area section-padding white-bg">
            <div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-8 mobi-mb-50">
                    <?php 
                    global $query_string;
                    wp_parse_str( $query_string, $search_args );
                    $search_query = new WP_Query($search_args);
                    $total_results = $search_query->found_posts ? $search_query->found_posts : 0;
                    echo '<h3>';
                    printf(__('We found %1$s articles for your search','glw'), $total_results );
                    echo '</h3>';
                    ?>
                    <div class="row">
                        <div class="col-12  mb-20">
                            <?php get_search_form( ); ?>
                        </div>
                    </div>
                    <?php
                    if( $search_query->have_posts() ):
                    ?>
						<div class="row">
							<?php
							while( $search_query->have_posts() ):
                                $search_query->the_post();
                                ?>
                                <div class="col-xs-12 col-sm-6 mb-30">
                                    <div class="blog-post">
                                        <div class="thumb text-center">
                                            <a href="<?php the_permalink( ); ?>">
                                            <?php
                                            the_post_thumbnail( 'grid_post_thumbnail', array(
                                                'alt'	=> get_post_meta( get_post_thumbnail_id(get_the_ID()),
                                                '_wp_attachment_image_alt', true)
                                            ) );
                                            ?>
                                            </a>
                                        </div>
                                        <div class="blog-content ptb-30 plr-35">
                                            <div class="date-box clearfix mb-20">
                                                <h4 class="theme-color pull-left no-margin"><?php echo get_the_time('d'); ?> <span><?php echo get_the_time('m') ?></span></h4>
                                                <div class="name-comment pl-15">
                                                    <h5 class=" mb-5"><span class="theme-color"><?php echo __('By: ', 'glw');?></span> <?php the_author(); ?></h5>
                                                    <h5 class="no-margin"><span class="theme-color"><?php echo __('Comments: ', 'glw'); ?></span> <?php echo get_comments_number( get_the_ID() ); ?></h5>
                                                </div>
                                            </div>
                                            <a href="<?php the_permalink( ); ?>">
                                                <h3 class="text-capitalize"><?php glw_highlight_search_keyword_title(); ?></h3>
                                            </a>
                                            <p><?php glw_highlight_search_keyword_excerpt(7); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php 
							endwhile;
							?>
						</div>
						<!-- /.row -->
						<div class="row">
							<div class="col-xs-12">
								<?php 
								glw_custom_pagination();
								?>
							</div>
						</div>
						<!-- /.row -->
						<?php
						endif;
						?>
					</div>
					<?php 
						get_sidebar();
					?>
				</div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </section>
        <!-- Blog Section End -->
<?php
get_footer();
?>