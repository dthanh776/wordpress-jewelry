<div class="col-xs-12 col-sm-6 col-md-3 mobi-mb-50 tab-mb-50">
        <?php 
        if(is_active_sidebar( 'glw_footer1_sidebar' )){
            dynamic_sidebar( 'glw_footer1_sidebar' );
        }
        ?>
</div>