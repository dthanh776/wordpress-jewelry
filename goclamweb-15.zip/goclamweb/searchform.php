<form class="search" role="search" method="get" action="<?php esc_url( home_url('/') ); ?>">
    <input 
    type="search" 
    name="s" 
    placeholder="<?php _e('Search anything ...','glw'); ?>" 
    value="<?php the_search_query( ); ?>"
    id="<?php esc_attr( uniqid('search-form-') ); ?>"
    />
    <button id="close" type="submit"><i class="zmdi zmdi-search"></i></button>
</form>