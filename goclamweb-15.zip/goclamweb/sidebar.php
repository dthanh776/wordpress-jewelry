<div class="col-xs-12 col-sm-4">
    <div class="sidebar white-bg">
        <?php 
        if(is_active_sidebar( 'glw_primary_sidebar' )){
            dynamic_sidebar( 'glw_primary_sidebar' );
        }
        ?>
    </div>
</div>
<!-- /.Sidebar End -->